/*global chrome, window, Image, console, localStorage, setInterval */

var tgs = (function () {

    "use strict";

    var gsTimes = [];

    function getGsHistory() {

        var result = localStorage.getItem('gsHistory2');
        if (result === null) {
            result = [];
        } else {
            result = JSON.parse(result);
        }
        return result;
    }

    function checkWhiteList(url) {

        var whitelist = localStorage.getItem('gsWhitelist') || "",
            whitelistedWords = whitelist.split(" "),
            i;

        for (i = 0; i < whitelistedWords.length; i++) {
            if (whitelistedWords[i].length > 0 && url.indexOf(whitelistedWords[i]) >= 0) {
                return true;
            }
        }
        return false;
    }

    function savePreviewData(tabUrl, previewUrl) {
        chrome.storage.local.get(null, function (items) {
            items.gsPreviews[tabUrl] = previewUrl;
            chrome.storage.local.set(items);
        });
    }

    function saveSuspendData(tab, previewUrl) {

        var gsHistory = getGsHistory(),
            tabProperties;

        if (previewUrl) {
            savePreviewData(tab.url, previewUrl);
        }

        if (tab.incognito) {
            tabProperties = {id: tab.id, date: new Date(), title: tab.title, url: tab.url, state: 'suspended', favicon: tab.favIconUrl };
        } else {
            tabProperties = {id: tab.id, date: new Date(), title: tab.title, url: tab.url, state: 'suspended', favicon: "chrome://favicon/" + tab.url };
        }

        //add suspend information to start of history array
        gsHistory.unshift(tabProperties);

        //clean up old items
        while (gsHistory.length > 100) {
            gsHistory.pop();
        }
        localStorage.setItem('gsHistory2', JSON.stringify(gsHistory));
    }

    function sendSuspendMessage(tab, callback) {

        chrome.tabs.executeScript(tab.id, {file: "html2canvas.min.js"}, function () {
            chrome.tabs.executeScript(tab.id, {file: "content_script.js"}, function () {

                chrome.tabs.sendMessage(tab.id, {}, function (response) {
                    var previewUrl = response ? response.previewUrl : '';
                    callback(tab, previewUrl);
                });
            });
        });
    }

    function suspendTab(tab) {

        //don't allow suspending of already suspended tabs
        if (tab.url.indexOf("chrome-extension") >= 0 || tab.url.indexOf("chrome:") >= 0) {
            return;
        }

        //check whitelist
        if (checkWhiteList(tab.url)) {
            return;
        }

        var preview = localStorage.getItem("preview") === "false" ? false : true;
        if (preview) {
            sendSuspendMessage(tab, function (tab, previewUrl) {
                saveSuspendData(tab, previewUrl);
                chrome.tabs.update(tab.id, {url: chrome.extension.getURL("suspended.html")});
            });

        } else {
            saveSuspendData(tab, false);
            chrome.tabs.update(tab.id, {url: chrome.extension.getURL("suspended.html")});
        }
    }

    function suspendSpecificTab(tab) {
        if (!tab.active) {
            suspendTab(tab);

        //if tab is active then refresh timer for this tab
        } else {
            gsTimes[tab.id] = new Date();
        }
    }
    function suspendActiveTab(window) {
        var i;
        for (i = 0; i < window.tabs.length; i += 1) {
            if (window.tabs[i].active) {
                suspendTab(window.tabs[i]);
            }
        }
    }
    function suspendAllTabs(window) {
        var i;
        for (i = 0; i < window.tabs.length; i += 1) {
            if (window.tabs[i].url.indexOf("suspended.html") < 0) {
                suspendTab(window.tabs[i]);
            }
        }
    }
    function unsuspendAllTabs(curWindow) {
        var i;
        for (i = 0; i < curWindow.tabs.length; i += 1) {

            //unsuspend if tab has been suspended
            if (curWindow.tabs[i].url.indexOf("suspended.html") >= 0) {
                chrome.tabs.sendMessage(curWindow.tabs[i].id, {action: "unsuspendTab"});
            }

            //reset timers for all tabs in this window
            gsTimes[curWindow.tabs[i].id] = new Date();
        }
    }

    function checkForTabsToAutoSuspend() {

        var timeToSuspend = localStorage.getItem("gsTimeToSuspend") || 0;

        if (timeToSuspend > 0) {

            chrome.tabs.query({}, function (tabs) {

                var i;
                for (i in tabs) {
                    if (tabs.hasOwnProperty(i)) {
                        if (gsTimes[tabs[i].id]) {
                            if (new Date() - gsTimes[tabs[i].id] >  timeToSuspend * 1000 * 60) {
                                suspendSpecificTab(tabs[i]);
                            }
                        } else {
                            gsTimes[tabs[i].id] = new Date();
                        }
                    }
                }
            });
        }
    }

    //add an initial time to all open tabs
    function initialiseAllTabs() {

        chrome.tabs.query({}, function (tabs) {

            var i;
            for (i in tabs) {
                if (tabs.hasOwnProperty(i)) {
                    gsTimes[tabs[i].id] = new Date();
                }
            }
        });
    }

    //check for tabs that have a state of 'suspended'
    function restoreCrashedTabs() {

        chrome.tabs.query({}, function (tabs) {
            //first check to see if there are any suspended tabs already
            var i,
                possibleCrash = true,
                openTabs = {},
                gsHistory;

            //if there is only one open tab then assume its a chrome restart (and don't restore)
            if (tabs.length < 2) {
                return;
            }

            for (i in tabs) {
                if (tabs.hasOwnProperty(i)) {
                    if (tabs[i].url.indexOf('suspended.html') >= 0) {
                        possibleCrash = false;
                        return;
                    } else {
                        openTabs[tabs[i].url] = true;
                    }
                }
            }

            //if it's possible that we have crashed then try to restore any tabs still in 'suspended' state
            gsHistory = getGsHistory();
            for (i = 0; i < gsHistory.length; i++) {
                if (gsHistory[i].state === 'suspended' && typeof (openTabs[gsHistory[i].url]) === 'undefined') {
                    chrome.tabs.create({active: false, url: chrome.extension.getURL("suspended.html"
                                                + "#id=" + gsHistory[i].id
                                                + "&url=" + gsHistory[i].url)});
                }
            }
        });
    }

    function checkForNewVersion() {

        var lastVersion = localStorage.getItem('gsVersion'),
            gsHistory,
            oldGsHistory,
            i;

        if (typeof (lastVersion) === 'undefined' || lastVersion !== '4.51') {

            //now we know they are on an old version but check to see if they are installing for the first time
            oldGsHistory = localStorage.getItem('gsHistory');

            //if they have gsHistory then they are upgrading
            if (oldGsHistory !== null) {

                //merge old gsHistory with new one
                gsHistory = getGsHistory();
                oldGsHistory = JSON.parse(oldGsHistory);
                for (i = 0; i < oldGsHistory.length; i++) {
                    gsHistory.push(oldGsHistory[i]);
                }
                localStorage.setItem('gsHistory2', JSON.stringify(gsHistory));
                localStorage.removeItem('gsHistory');

                chrome.tabs.create({url: chrome.extension.getURL("update.html")});
            }
            localStorage.setItem('gsVersion', '4.51');
        }
    }

    //handler for popup clicks
    chrome.extension.onRequest.addListener(
        function (request, sender, sendResponse) {

            if (request.msg === "suspendOne") {
                chrome.windows.getLastFocused({populate: true}, suspendActiveTab);

            } else if (request.msg === "suspendAll") {
                chrome.windows.getLastFocused({populate: true}, suspendAllTabs);

            } else if (request.msg === "unsuspendAll") {
                chrome.windows.getLastFocused({populate: true}, unsuspendAllTabs);
            }
        }
    );

    //listen for tab switching
    chrome.tabs.onSelectionChanged.addListener(function (tabId, info) {
        if (gsTimes[tabId]) {
            gsTimes[tabId] = new Date();
        }
    });

    initialiseAllTabs();

    restoreCrashedTabs();

    checkForNewVersion();

    //start timer
    setInterval(function () {
        checkForTabsToAutoSuspend();
    }, 1000 * 60);

}());